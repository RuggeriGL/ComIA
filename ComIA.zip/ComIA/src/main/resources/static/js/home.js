function getStarted() {
    alert("Bienvenido a ComIA. ¡Explora nuestras recetas y comienza tu aventura culinaria!");

}
